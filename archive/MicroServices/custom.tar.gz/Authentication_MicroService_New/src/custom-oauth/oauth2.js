// dependencies
var OAuth2Strategy = require('passport-oauth2').Strategy;
var passport = require('passport');
var verify = require('../providers/middleware/verify');
var authProvider = require('../providers/middleware/auth-provider');
var scope = [];
var jwtVerifyPrehooks = require('../jwt/verifyHooks');
var jwt = require('../jwt/jwt');
var constants = require('../constants.json');

//Read the config key value from env variables. This will return a JSON string with '=>' symbol in place of ':'
//Replace '=>' symbol with ':' to convert to JSON string and parse to retrieve JSON object
var envJson;
var config;
if(process.env.config) {
    envJson = process.env.config;
    envJson = envJson.replace(/=>/g, ':');
    config = JSON.parse(envJson);
}

// Configure the Facebook strategy for use by Passport.
//
// OAuth 2.0-based strategies require a `verify` function which receives the
// credential (`accessToken`) for accessing the Facebook API on the user's
// behalf, along with the user's profile.  The function must invoke `done`
// with a user object, which will be set at `req.user` in route handlers after
// authentication.
/*if (config.configuration && config.configuration.facebook && config.configuration.facebook.clientID && config.configuration.facebook.clientSecret && config.configuration.facebook.scope) {
    scope = config.configuration.facebook.scope; */

passport.use(new OAuth2Strategy({
        authorizationURL: 'https://login.microsoftonline.com/9c5f32b8-daee-45fe-bc9c-10aecd2bc4db/oauth2/authorize',
        tokenURL: 'https://login.microsoftonline.com/9c5f32b8-daee-45fe-bc9c-10aecd2bc4db/oauth2/token',
        clientID: '7119d908-d06d-4937-9ef6-f02f609ac05f',
        clientSecret: 'rd7bTr4kO3X/X9V4+WH1xw+RfaqXXHAht4B+CSA60BI=',
        callbackURL: "http://localhost:3000/auth/customOauth/callback",
        resource:"http://localhost:3000/auth/customOauth/resource"



    },
    function(accessToken, refreshToken, profile, cb) {

        var user = {
            "accessToken" : accessToken,
            "refreshToken" : refreshToken,
            "profile" : profile

        };
        return cb(null, user);


    }
));



//}


function customOauth(app){


    app.get('/auth/customOauth',  function(req,res,next) {
        passport.authenticate('oauth2') (req,res,next);
    });




    // GET /auth/customOauth/callback
    //   Use passport.authenticate() as route middleware to authenticate the request.
    //   On success Prepare profile data and encrypt as code.
    //   Developer has to call /account method to decrypt the code to get user account details
   app.get('/auth/customOauth/callback',
           passport.authenticate('oauth2', { failureRedirect: '/login',resource:"http://localhost:3000/auth/customOauth/resource"}),
        function(req, res) {
          // In the req.user will have accessToken and refreshToken
            res.send(200,req.user);


        }
    );

}

module.exports = customOauth;
