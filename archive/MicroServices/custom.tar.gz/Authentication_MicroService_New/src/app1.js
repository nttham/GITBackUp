/**
 * Created by cognizant on 23/08/16.
 */
var express = require('express');
var app = express();
var port = process.env.PORT || 3000;
app.listen(port);
console.log("Running on port :"+port);
module.exports = app;
app.use('*',  function (req, res,next) {

        console.log("resource route ********");
        next();
    }
);