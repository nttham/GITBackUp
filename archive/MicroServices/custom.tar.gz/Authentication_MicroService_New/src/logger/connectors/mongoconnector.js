
var mongoose = require('mongoose');
var envJson;

var config;
var services_vcap = JSON.parse(process.env.VCAP_SERVICES || "{}");
console.log('**** service VCAP ****: '+JSON.stringify(services_vcap));
if( services_vcap && services_vcap["Mongo Service"]) {
    var config1 = services_vcap["Mongo Service"][0].credentials;
    config = {
        logger : config1
    }

}
else if(process.env.config){
    envJson = process.env.config;
    envJson = envJson.replace(/=>/g, ':');
    config = JSON.parse(envJson);
}


function mongoConnection()
{
    this.mongoConnect=function(requestObj,callback)
    {
        console.log('STEP7: IN mongoConnection()');
        console.log('STEP7a: IsMongoConnection open: ',requestObj.mongoConnect);
        if (requestObj.mongoConnect != undefined) {
            console.log('STEP8: mongo connection exists so returning the same connection object');
            callback(requestObj.mongoConnect);
        }
        else {
            console.log('STEP8: mongo connection Initiation');
            if( services_vcap && services_vcap["Mongo Service"]) {
                console.log('INSIDE NEW MONGO INSTANCE: '+JSON.stringify(config));
                var host = config.logger.host;
                var port = config.logger.port;
                var dbname = config.logger.database;
                var username = config.logger.username;
                var password = config.logger.password;

            }
            else{
                console.log('INSIDE EXTERNAL MONGO INSTANCE: '+JSON.stringify(config));
                var host = config.logger.hostname;
                var port = config.logger.portNo;
                var dbname = config.logger.dbName;
                var username = config.logger.username;
                var password = config.logger.password;
            }
            // "mongodb://admin:1e2Pjjd@54.169.162.137:10053"
            // url = "mongodb://"+username+":"+password+"@" + host + ":" + port + "/" + dbname;
            url = "mongodb://"+ host + ":" + port + "/" + dbname;

            console.log('STEP9: mongo connection URL: ',url);
            var responseObj = '';

            mongoose.connect(url, {auth: {authdb: 'admin'}}, function (err, db) {
                if (!err) {
                    console.log('STEP10: mongo connected successfully DB');
                    var logItemScema = new mongoose.Schema({
                        priority: String,
                        level: String,
                        datetime: Date,
                        msg: String,
                        appid: String
                    });

                    requestObj.mongoConnect = mongoose.model('applog', logItemScema);
                    responseObj = mongoose.model('applog', logItemScema);
                }
                else {
                    console.log('STEP10: MONGO CONNECTION ERROR', err);
                    requestObj.mongoConnect = err;
                    responseObj = err;
                }
                callback(responseObj);
            });


        }
    }

    this.mongoDisconnect = function(){
        console.log('STEP19: In side connection disconnect....');
        delete mongoose.models.applog;
        mongoose.connection.close(function (err,res) {
            console.log("STEP20: Any error "+err)
            console.log('STEP21: Mongoose disconnected successfully');
        });


    }
}




module.exports = mongoConnection;


