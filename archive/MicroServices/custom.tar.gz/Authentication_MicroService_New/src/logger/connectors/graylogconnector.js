/**
 * Created by trujun on 26/05/16.
 */
var log = require('gelf-pro');
var envJson;

var config;
var services_vcap = JSON.parse(process.env.VCAP_SERVICES || "{}");
if( services_vcap && services_vcap["Mongo Service"]) {
    var config1 = services_vcap["Mongo Service"][0].credentials;
    config = {
        logger : config1
    }

}
else if(process.env.config){
    envJson = process.env.config;
    envJson = envJson.replace(/=>/g, ':');
    config = JSON.parse(envJson);
}


function graylogConnection(requestObj)
{
    console.log('STEP5: IN graylogConnector: ',requestObj.graylogger);

    if(requestObj.graylogger != undefined){
        return;
    }
    else {
        console.log('STEP6: initiate graylogger');
        // var persistantStoreConf = require('../configuration/config');
        // var config = persistantStoreConf.graylog;


        log.setConfig({
            fields: {facility: "logger-service", owner: "CognizantOne"},
            adapterName: "udp", // currently supported "udp" only
            adapterOptions: {
                protocol: config.logger.loggerprotocol|| "udp4", // udp adapter: udp4, udp6
                host: config.logger.host||"54.208.196.90",
                port: config.logger.port || "12201",
            }
        });
        return requestObj.graylogger = log;
    }
}
exports.graylogConnection = graylogConnection;