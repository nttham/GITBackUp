/**
 * Created by Srividya on 23/06/16.
 */
var request = require('request');
var async = require('async');

var getData = function (callback) {
    //forming http request string
    var getOptions = {
        url: 'https://api.github.com/gists/a0a7db06eb449c231937504a565ce06b',
        method: 'GET',
        headers: {
            'Authorization': 'Basic U3VyeWFrYWxhLkJvdHRhQGNvZ25pemFudC5jb206U3VyeWExMjM=',
            'user-agent': 'node.js',
            Accept: 'application/json'
        }
    };

    request(getOptions, function (err, response) {
        if (err) {
            console.log('Error raised while fetching logger json: '+err);
            return callback(err);
        }
        else {
            return callback(null, response);
        }
    });
};


var editData = function (obj, callback) {
    var editGetCallback = function (error,result) {
        if (error) {
            callback(error);
        }
        else {
            var filesData = JSON.parse(result.body).files['logger.json'].content;
            var contentArray = JSON.parse(filesData);
            contentArray.push(obj);

            var body = {
                description: "the description for this gist",
                files: {
                    "logger.json": {
                        content: JSON.stringify(contentArray)
                    }
                }
            };

            //forming http request string
            var postOptions = {
                url: 'https://api.github.com/gists/a0a7db06eb449c231937504a565ce06b',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Basic U3VyeWFrYWxhLkJvdHRhQGNvZ25pemFudC5jb206U3VyeWExMjM=',
                    'user-agent': 'node.js'
                },
                body: JSON.stringify(body)
            };

            request(postOptions, function (err, response) {
                if (err) {
                    return callback(err);
                }
                else {
                    return callback(null, JSON.stringify(response));
                }
            });
        }
    };

    async.waterfall([getData], editGetCallback);
};


var deleteData = function (obj, callback) {

    var deleteGetCallback = function (error,result) {
        if (error) {
            callback(error);
        }
        else {
            var filesData = JSON.parse(result.body).files['logger.json'].content;
            var contentArray = JSON.parse(filesData);
            //var index = contentArray.findIndex(x => x.instance_id==obj.instance_id);

            var index;
            for(index = 0; index < contentArray.length; index++) {
                var detail = contentArray[index];
                if(detail.instance_id === obj.instance_id) {
                    break;
                }
            }
            console.log('Index: ',index);
            contentArray.splice(index,1);

            var body = {
                description: "the description for this gist",
                files: {
                    "logger.json": {
                        content: JSON.stringify(contentArray)
                    }
                }
            };

            //forming http request string
            var postOptions = {
                url: 'https://api.github.com/gists/a0a7db06eb449c231937504a565ce06b',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Basic U3VyeWFrYWxhLkJvdHRhQGNvZ25pemFudC5jb206U3VyeWExMjM=',
                    'user-agent': 'node.js'
                },
                body: JSON.stringify(body)
            };

            request(postOptions, function (err, response) {
                if (err) {
                    return callback(err);
                }
                else {
                    return callback(null, JSON.stringify(response));
                }
            });
        }
    };
    async.waterfall([getData], deleteGetCallback);
};

exports.getData = getData;
exports.editData = editData;
exports.deleteData = deleteData;
