$(function() {
    console.log( "ready!" );
});

